import math


def brute_force(xs):
    pass


def greedy(xs):
    pass


def dp(xs):
    pass

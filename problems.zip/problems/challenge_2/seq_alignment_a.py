'''
Challenge 2a
'''

def sequence_align(x, y, c, delta) -> list:
    pass
